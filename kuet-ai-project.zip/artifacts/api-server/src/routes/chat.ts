import { Router } from "express";

const router = Router();

const SYSTEM_PROMPT = `You are KUET AI Student Helper.

Rules:
- Answer shortly and clearly.
- Focus on KUET, admission, departments, routines, halls, academics.
- Reply in Bangla if user speaks Bangla.
- If unsure, say "I am not fully sure".`;

router.post("/chat", async (req, res) => {
  const { messages } = req.body as {
    messages: Array<{ role: string; content: string }>;
  };

  if (!messages || !Array.isArray(messages)) {
    res.status(400).json({ error: "messages array is required" });
    return;
  }

  const apiKey = process.env["GROQ_API_KEY"];
  if (!apiKey) {
    res.status(503).json({ error: "AI service not configured. Please add your Groq API key." });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        stream: true,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      req.log.error({ status: response.status, err }, "OpenRouter API error");

      let userMessage = "Something went wrong. Please try again.";
      if (response.status === 429) {
        userMessage = "The AI service is currently rate-limited. Please wait a moment and try again.";
      } else if (response.status === 401 || response.status === 403) {
        userMessage = "The AI service is not properly configured. Please check your OpenRouter API key.";
      } else if (response.status === 400) {
        userMessage = "Invalid request. Please try rephrasing your question.";
      }

      res.write(`data: ${JSON.stringify({ error: userMessage })}\n\n`);
      res.end();
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) {
      res.write(`data: ${JSON.stringify({ error: "No response stream" })}\n\n`);
      res.end();
      return;
    }

    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data: ")) continue;
        const raw = trimmed.slice(6).trim();
        if (!raw || raw === "[DONE]") continue;

        try {
          const json = JSON.parse(raw);
          const text = json.choices?.[0]?.delta?.content;
          if (text) {
            res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
          }
        } catch {
          // skip malformed chunks
        }
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Chat stream error");
    res.write(`data: ${JSON.stringify({ error: "Unexpected error. Please try again." })}\n\n`);
    res.end();
  }
});

export default router;
