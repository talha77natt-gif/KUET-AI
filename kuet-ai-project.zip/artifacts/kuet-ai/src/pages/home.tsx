import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { FileText, Building2, Bell, Bot, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  {
    id: "admission",
    title: "Admission Information",
    description: "Get the latest updates on undergraduate and postgraduate admission requirements and deadlines.",
    icon: FileText,
  },
  {
    id: "departments",
    title: "Department Details",
    description: "Explore all engineering and science departments, faculty members, and syllabus details.",
    icon: Building2,
  },
  {
    id: "notices",
    title: "KUET Notices",
    description: "Stay informed with real-time access to administrative announcements, academic calendars, and event notices.",
    icon: Bell,
  },
  {
    id: "ai-assistant",
    title: "AI Search Assistant",
    description: "Ask natural language questions and get instant, accurate answers about anything related to KUET.",
    icon: Bot,
  },
];

export default function Home() {
  const [, setLocation] = useLocation();

  const scrollToFeatures = () => {
    const featuresSection = document.getElementById("features");
    if (featuresSection) {
      featuresSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/20 selection:text-primary">
      {/* Navigation */}
      <motion.nav 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="w-full flex items-center justify-between px-6 md:px-12 py-6 max-w-7xl mx-auto"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
            <Bot className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-bold text-xl tracking-tight text-foreground">KUET AI</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-primary transition-colors duration-200" data-testid="link-home">Home</button>
          <button onClick={scrollToFeatures} className="hover:text-primary transition-colors duration-200" data-testid="link-features">Features</button>
          <a href="mailto:contact@kuet.ac.bd" className="hover:text-primary transition-colors duration-200" data-testid="link-contact">Contact</a>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col">
        <section className="flex-1 flex flex-col items-center justify-center px-6 text-center max-w-4xl mx-auto py-20 md:py-32">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="space-y-6 flex flex-col items-center"
          >
            <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm font-medium text-primary mb-4" data-testid="badge-status">
              <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse"></span>
              System Online
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground leading-[1.1]">
              Your smart AI guide for <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">KUET information</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl font-medium leading-relaxed">
              Find notices, admission info, department details, and more instantly. Like having a brilliant senior who knows everything.
            </p>

            <div className="pt-8">
              <Button 
                onClick={() => setLocation("/chat")}
                size="lg" 
                className="h-14 px-8 text-lg font-semibold rounded-2xl shadow-xl shadow-primary/25 hover:shadow-primary/40 transition-all duration-300 hover:-translate-y-0.5 group"
                data-testid="button-enter"
              >
                Enter Portal
                <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </motion.div>
        </section>

        {/* Features Section */}
        <section id="features" className="w-full bg-muted/30 py-24 px-6 md:px-12 relative overflow-hidden">
          <div className="max-w-7xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Everything you need, in one place</h2>
              <p className="text-muted-foreground text-lg">Intelligent search designed specifically for our campus.</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ y: -8 }}
                  className="bg-card border border-card-border p-8 rounded-3xl shadow-sm hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 group"
                  data-testid={`card-feature-${feature.id}`}
                >
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                    <feature.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-10 text-center">
        <p className="text-sm font-medium text-muted-foreground" data-testid="text-footer">
          Made for KUET Students
        </p>
      </footer>
    </div>
  );
}
